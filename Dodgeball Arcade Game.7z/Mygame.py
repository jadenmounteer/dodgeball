"""
This file contains the myGame class which is used to set up the game logic.
The Mygame class uses the other classes to set up the game.
"""
# --- Imports ---
import arcade
import background_classes
import main
import player
import ball
 
class MyGame(arcade.Window):
    """
    Main application class.

    NOTE: Go ahead and delete the methods you don't need.
    If you do need a method, delete the 'pass' and replace it
    with your own code. Don't leave 'pass' in this program.
    """

    def __init__(self, width, height, title):
        #Inherits the Arcade parent class
        super().__init__(width, height, title)

        #Sets the background color for the game.
        arcade.set_background_color(main.BACKGROUND_COLOR)

        # These are used if the player is holding down an arrow key.
        self.holding_right = False
        self.holding_left = False
        self.holding_up = False
        self.holding_down = False
        self.holding_space = False
        self.close_to_ball = False # This is turned True if the player is near a ball.
        self.ball_close_to = ""

        # If you have sprite lists, you should create them here,
        # and set them to None

        # Creates a gym using the Gym class.
        self.gym = background_classes.Gym()
        # Creates a player from the Player class to represent the player.
        self.player_avatar = player.Player()
        # Creates an instance of a Ball class to represent a dodgeball.
        self.dodgeball_1 = ball.Ball(main.SCREEN_WIDTH / 2, main.SCREEN_HEIGHT / 2, arcade.color.RED)


    def setup(self):
        """ Set up the game variables. Call to re-start the game. """
        # Create your sprites and sprite lists here


    def on_draw(self):
        """
        Render the screen.
        """

        # This command should happen before we start drawing. It will clear
        # the screen to the background color, and erase what we drew last frame.
        arcade.start_render()

        # Draws the gym to the screen.
        self.gym.draw_gym()

        # Draws a dodgeball to the screen.
        self.dodgeball_1.draw_ball()

        # Draws the player to the screen.
        self.player_avatar.draw_player()

    def on_update(self, delta_time):
        """
        All the logic to move, and the game logic goes here.
        Normally, you'll call update() on the sprite lists that
        need it.
        """
        # Checks to see if the player is close to a ball. If so, calls the player_close_to_ball() function to change the ball_close_to to the name of the dodgeball.
        # If the player is close to a ball, changes the self.close_to_ball boolean to True.
        self.close_to_ball()

        # Checks to see if keys are being held, and then takes appropriate action.
        self.check_keys()
    
    def close_to_ball(self):
        """
        This function checks to see if the player is near a ball by going through a list of all the balls created in the game.
        Whichever ball the player is nearest, that ball is added to the variabble, self.ball_close_to.
        """
        # If the distance between the player and the ball is less than 30, change the ball close to variable.
        if self.player_avatar.center_x 
    
    def check_keys(self):
        """
        Checks to see if the user is holding down a key.
        If so, calls the appropriate method.
        """
        #          ---PLAYER ACTIONS ---
        # If the player is holding the right arrow key.
        if self.holding_right:
            # Moves the player up court.
            self.player_avatar.move_up_court()
        # If the player is holding the left arrow key.
        if self.holding_left:
            # Moves the player down court.
            self.player_avatar.move_down_court()
        # If the player is holding the down arrow key.
        if self.holding_down:
            # Moves the player to the left of the court.
            self.player_avatar.move_left()
        # If the player is holding the up arrow key.
        if self.holding_up:
            # Moves the player to the right of the court.
            self.player_avatar.move_right()
        # If the player presses the space bar and is close to a ball.
        if self.holding_space and self.close_to_ball:
            # Calls the player's pick up ball method.
            self.player_avatar.pick_up_ball(self.ball_close_to)


    def on_key_press(self, key, key_modifiers):
        """
        Called whenever a key on the keyboard is pressed.
        Checks which key is being pressed and then switches the boolean value to True.

        For a full list of keys, see:
        http://arcade.academy/arcade.key.html
        """
        if key == arcade.key.UP:
            self.holding_up = True
        if key == arcade.key.DOWN:
            self.holding_down = True
        if key == arcade.key.RIGHT:
            self.holding_right = True
        if key == arcade.key.LEFT:
            self.holding_left = True
        if key == arcade.key.SPACE:
            self.holding_space = True

    def on_key_release(self, key, key_modifiers):
        """
        Called whenever the user lets off a previously pressed key.
        Checks which key is not being pressed and then switches the boolean value to False.
        """
        if key == arcade.key.UP:
            self.holding_up = False
        if key == arcade.key.DOWN:
            self.holding_down = False
        if key == arcade.key.RIGHT:
            self.holding_right = False
        if key == arcade.key.LEFT:
            self.holding_left = False
        if key == arcade.key.SPACE:
            self.holding_space = True

    def on_mouse_motion(self, x, y, delta_x, delta_y):
        """
        Called whenever the mouse moves. 
        """
        pass

    def on_mouse_press(self, x, y, button, key_modifiers):
        """
        Called when the user presses a mouse button.
        """
        pass

    def on_mouse_release(self, x, y, button, key_modifiers):
        """
        Called when a user releases a mouse button.
        """
        pass