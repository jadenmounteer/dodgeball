"""
File: Player.py
AuthorL Jaden Mounteer

This file creates a class for the player in the dodgeball game.
The player will be a circle on one side of the screen. He will be able to move around in all directions, but not be able to cross the center line.
He will be able to pick up balls and throw them at the other player.
"""
import arcade
import main

class Player():
    """
    This class represents the player in the game, which will be a circle for now.
    """
    def __init__(self):
        """
        Initiates the player's member variables.
        """
        self.center_x = main.SCREEN_WIDTH - 50 # Starts the player on the back wall, depending on the size of the screen.
        self.center_y = main.SCREEN_HEIGHT / 2 # Starts the player on the middle of the wall, depending on the size of the screen.
        self.radius = (main.SCREEN_HEIGHT * main.SCREEN_WIDTH) / 16000 # Determines the player's size by the area of the screen.
        self.color = arcade.color.BLUE
        self.speed = 5
    
    def draw_player(self):
        """
        Draws the player to the screen.
        """
        # Draws a circle to the screen to represent the player, for now.
        arcade.draw_circle_filled(center_x=self.center_x, center_y=self.center_y, radius=self.radius, color=self.color)
    
    def move_down_court(self):
        """
        Allows the player to move down the x axis.
        """
        self.center_x -= self.speed
    
    def move_up_court(self):
        """
        Allows the player to move up the x axis.
        """
        self.center_x += self.speed
    
    def move_right(self):
        """
        Allows the player to move up the y axis.
        """
        self.center_y += self.speed
    
    def move_left(self):
        """
        Allows the player to move down the y axis.
        """
        self.center_y -= self.speed

    def pick_up_ball(self, ball):
        """
        Causes the player to pick up a ball.
        Takes a ball as a parameter.
        If the player is close to a ball, he picks it up.
        If not, he doesn't.
        """
        pass

    def throw_ball(self):
        """
        Causes the player to throw a ball if he has one in his hands.
        """
        pass


