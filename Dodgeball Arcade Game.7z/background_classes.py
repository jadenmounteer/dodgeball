"""
File: background_classes.py
Author: Jaden Mounteer

This file contains the classes used to draw the background objects in the game.
"""
# --- Imports ---
import arcade
import main

class Line():
    """
    This class creates a line in the game.
    The line is used to separate the fields in the game.
    """
    def __init__(self):
        """
        Initiates the line's variables.
        """
        self.startx = main.SCREEN_WIDTH / 2 
        self.starty = 25
        self.endx = main.SCREEN_WIDTH / 2
        self.endy = main.SCREEN_HEIGHT - 25
        self.width = 5

    def draw_center_line(self):
        """
        This function draws a line in the center of the screen.
        """
        arcade.draw_line(start_x=self.startx, start_y=self.starty, end_x=self.endx, end_y=self.endy, 
                        color=arcade.color.BLACK, line_width=self.width)

class Circle():
    """
    This class represents the circle painted onto the gym floor.
    """
    def draw_circle(self):
        """
        This function draws the circle onto the screen.
        """
        arcade.draw_circle_outline(center_x=main.SCREEN_WIDTH / 2, center_y=main.SCREEN_HEIGHT / 2, radius=50, color=arcade.color.BLACK)


class Gym():
    """
    This class represents the gymnasium background.
    """
    def draw_gym(self):
        """
        This function draws the gym background.
        """
        #Creates an instance of the Line class in order to make a center line.
        center_line = Line()
        center_line.draw_center_line()

        #Creates an instance of the cicle painted onto the gym floor and draws it to the screen.
        center_circle = Circle()
        center_circle.draw_circle()

        # Draws the square to the screen. This square shows the out of bounds lines.
        arcade.draw_rectangle_outline(center_x=main.SCREEN_WIDTH / 2, center_y=main.SCREEN_HEIGHT / 2, 
                                        height= main.SCREEN_HEIGHT - 50, color = arcade.color.BLACK, 
                                        width=main.SCREEN_WIDTH - 50, border_width= 5)
        
        # Draws the two circles that represent the circles around the basketball hoops.
        

