"""
File: ball.py
Author: Jaden Mounteer

This file represents the balls in the game.
They will spawn on the middle line. The player and enemies can pick them up and throw them.
"""
import arcade

class Ball():
    """
    This class represents a ball. 
    It can be picked up and thrown.
    """
    def __init__(self, center_x, center_y, color):
        """
        Initiates the ball's member variables.
        """
        self.center_x = center_x
        self.center_y = center_y
        self.radius = 10
        self.color = color
        self.speed = 10
    
    def draw_ball(self):
        """
        Draws a ball to the screen.
        """
        arcade.draw_circle_filled(center_x=self.center_x, center_y=self.center_y, radius=self.radius, color=self.color)
    
    def roll(self):
        """
        If the ball is touched by the player, another NPC, or another ball,
        it will roll in the opposite direction at the speed it was touched.
        It will gradually lose speed and slow to a stop.
        """