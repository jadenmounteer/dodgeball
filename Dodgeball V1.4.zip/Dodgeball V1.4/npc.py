"""
File: npc.py
Author: Jaden Mounteer

This file creates a base class for the NPCs in the game.
"""
# ___IMPORTS___
import arcade
import main
import random

class Npc:
    """
    A non-user player in the game.
    Picks up balls, throws balls, and dodges balls.
    """
    def __init__(self, centerx, centery, color, team):
        self.center_x = centerx
        self.center_y = centery
        self.color = color
        self.team = team
        self.radius = (main.SCREEN_HEIGHT * main.SCREEN_WIDTH) / 16000
        self.speed = 2 #5
        self.holding_ball = False
        self.in_game = True
        self.in_the_path_of_an_opponents_ball = False
        self.aware_of_nearby_balls = False
        self.incoming_ball = ""
        self.dodging_count = 0
    
    def advance(self, opposing_team_player, ball_1, ball_2, ball_3):
        """
        Takes all the balls and opponents as parameters.
        Moves the npc.
        Makes the npc do the following:
        If there are balls on its side of the line, goes for the nearest one.
        Picks up and throws balls. Aims at the opposing player or npcs.
        If there is a ball being thrown by the opposite team on its same y-axis, 
        moves up or down the y axis to get away from the oncoming dodegball. There is a chance
        the dodge isn't successful.
        If the npc is feeling lucky, tries to catch an oncoming ball.
        :returns: None
        """

        # Checks to see if there is a ball being thrown by the opposing team on its same y-axis.
        self.incoming_ball = self.check_to_see_if_there_are_incoming_balls(opposing_team_player, ball_1, ball_2, ball_3)

        # Determines which ball is coming at the player.
        if self.incoming_ball == ball_1.name:
            self.incoming_ball = ball_1
        elif self.incoming_ball == ball_2.name:
            self.incoming_ball = ball_2
        elif self.incoming_ball == ball_3.name:
            self.incoming_ball = ball_3

        # If there is a ball coming at the player, attempts to dodge out of the way.
        if self.in_the_path_of_an_opponents_ball and self.incoming_ball.being_thrown_by_player:
            if self.dodging_count < 10:
                self.try_to_dodge_incoming_ball(ball_1, ball_2, ball_3)
            # Increments the dodging count so that the npc only dodges enough.
            self.dodging_count += 1

        if not self.in_the_path_of_an_opponents_ball:
            self.dodging_count = 0


        # The npc checks to see if it was hit
        self.check_to_see_if_it_was_hit(ball_1, ball_2, ball_3)

        # If it was, the npc is out.
        if self.in_game == False:
           self.out()

        # If the npc isn't holding a ball, checks to see if there is a ball on it's side of the line that isn't being held by another teammate. 
        # If so, moves toward is.
        if self.holding_ball == False:
            self.go_for_nearest_ball(ball_1, ball_2, ball_3)
            # As soon as the NPC is near enough to the ball, picks it up.
            self.pick_up_ball(ball_1, ball_2, ball_3)

        # While holding a ball, the npc locates the nearest oppenent.
        self.locate_opponent(opposing_team_player)

        # When an opponent is located, the npc throws the dodgeball at the opponent.
        self.throw_ball_at_opponent()
    
    def draw_npc(self):
        """
        Draws the npc to the screen.
        """
        arcade.draw_circle_filled(center_x=self.center_x, center_y=self.center_y, radius=self.radius, color=self.color)
    
    def move_up_court(self):
        """
        Moves the npc up court.
        Stops the npc from crossing the middle line
        and the far right wall.
        """
        # If the npc tries to cross the middle line
        if self.center_x == main.SCREEN_WIDTH / 2:
            # Stops moving forward
            self.center_x = self.center_x
        # If the NPC reaches the right out of bounds line.
        elif self.center_x == main.SCREEN_WIDTH - 50:
            # Stops moving forward.
            self.center_x = self.center_x
        else:
            # Moves the npc up the x axis.
            self.center_x += self.speed

    def move_down_court(self):
        """
        Moves the npc down court.
        Stops the npc from crossing te middle line
        and the far left wall.
        """
        # If the npc tries to cross the middle line
        if self.center_x == main.SCREEN_WIDTH / 2:
            # Stops moving forward
            self.center_x = self.center_x
        # If the NPC reaches the left out of bounds line.
        elif self.center_x == 50:
            # Stops moving forward.
            self.center_x = self.center_x
        else:
            # Moves the npc down the x axis.
            self.center_x -= self.speed
        
    
    def move_up(self):
        """
        Moves the npc up the y axis.
        Stops the npc from crossing the top lines
        """
        # If the npc tries to cross the top out of bounds line
        if self.center_y == main.SCREEN_HEIGHT - 50:
            # Stops moving.
            self.center_y =self.center_y
        else:
            # Moves the npc up the y axis.
            self.center_y += self.speed

    def move_down(self):
        """
        Moves the npc down the y axis.
        If the npc is in the game, stops it from crossing the line.
        If the npc is out of the game, it can go out of bounds.
        """
        # If the NPC is in the game and tries to cross the bottom line.
        if self.in_game == True and self.center_y == 50:
            self.center_y = self.center_y
        else:
            # Moves the npc down the y axis.
            self.center_y -= self.speed
    
    # TODO: Put a random chance element in this method. Finish it.
    def check_to_see_if_there_are_incoming_balls(self, opposing_team_player, ball_1, ball_2, ball_3):
        """
        Checks to see if there is a ball being thrown by the opposing team on its same y-axis.
        Changes self.in_the_path_of_an_opponents_ball to either True or False.
        :return: The name of the ball coming at the player.
        """
        # Makes a list of balls in the game
        dodgeballs = [ball_1, ball_2, ball_3]

        # Iterates through the list.
        for ball in dodgeballs:
            # Checks to see if any are being thrown by an opponent and if it is on the same y axis as the npc.
            if ball.being_thrown_by_player:
                # Calculates the distance
                distance = ball.center_y - self.center_y
                # Changes distance to a positive number
                if distance < 0:
                    distance *= -1
                # Decides if the ball is close enough.
                if distance <= 100:
                    # NPC decides to try to jump out of the way of the ball
                    self.in_the_path_of_an_opponents_ball = True
                    # Returns the name of the ball coming at the player.
                    return ball.name

    def try_to_dodge_incoming_ball(self, ball_1, ball_2, ball_3):
        """
        If there is an incoming ball, attempts to dodge out of the way.
        Changes self.in_the_path_of_an_opponents_ball back to False.
        """
        # If the npc is above the ball
        if self.incoming_ball.center_y > self.center_y:
            # Move down.
            self.move_down()
            # If the npc is below the ball or on the same axis.
        elif self.incoming_ball.center_y <= self.center_y:
            # Move up.
            self.move_up()
        self.in_the_path_of_an_opponents_ball = False


    # TODO: Finish this function.
    def check_to_see_if_it_was_hit(self, ball_1, ball_2, ball_3):
        """
        The npc checks to see if it was hit
        Changes self.in_game to False if hit.
        """
        pass
    
    # TODO: Finish this function.
    def out(self):
        """
        If it was, the npc is out.
        Changes a member variable.
        Moves down to the bottom of the screen.
        """
        pass
    
    # TODO: Finish this function.
    def go_for_nearest_ball(self, ball_1, ball_2, ball_3):
        """
        Takes all the balls in the game as a parameter.
        Checks to see if there is a ball on it's side of the line 
        that isn't being held by another teammate. If so, moves towards
        the nearest one..
        """
        #TODO: Redo some of this code. First, create a list of available balls by appending balls to the list.
        # Maybe even make it so that, if the npc isn't aware of a ball, have a function that returns a list of available balls, then a function that iterates that
        # list and finds the closest one, then this function causes the npc to be aware of a ball. If the npc is aware of a ball, it moves toward it.

        # __Checks to see if there are any balls within the team's square__.
        # Put all the balls in the game into a list.
        dodgeballs = [ball_1, ball_2, ball_3]
        # Determines which team the npc is on and then iterates through the list and checks where each ball is at
        if self.team == "1":
            for ball in dodgeballs:
                if ball.center_x >= main.SCREEN_WIDTH / 2:
                    self.aware_of_nearby_balls = True
                    break
        elif self.team == "2":
            for ball in dodgeballs:
                if ball.center_x <= main.SCREEN_WIDTH / 2:
                    self.aware_of_nearby_balls = True
                    break

        # __If the npc is aware of nearby balls, grabs the distance of each ball and stores it in a list__.
        if self.aware_of_nearby_balls:
            # grabs the distance of each ball.
            d1 = self.get_distance(ball_1)
            d2 = self.get_distance(ball_2)
            d3 = self.get_distance(ball_3)
            distance_list = [d1, d2, d3]
            # Grabs the ball with the minimum distance.
            minimum_distance = min(distance_list)
            if minimum_distance == d1:
                ball_with_minimum_distance = ball_1
            elif minimum_distance == d2:
                ball_with_minimum_distance = ball_2
            elif minimum_distance == d3:
                ball_with_minimum_distance = ball_3
            print(minimum_distance)

            # __Heads towards that ball__
            if ball_with_minimum_distance.center_x > self.center_x:
                self.center_x += self.speed
            elif ball_with_minimum_distance.center_x < self.center_x:
                self.center_x -= self.speed
            elif ball_with_minimum_distance.center_y > self.center_y:
                self.center_y += self.speed
            elif ball_with_minimum_distance.center_y < self.center_y:
                self.center_y -= self.speed
            else:
                self.center_x = self.center_x
                self.center_y = self.center_y
    
    # TODO: Finish this function.
    def pick_up_ball(self, ball_1, ball_2, ball_3):
        """
        As soon as the NPC is near enough to the ball, picks it up.
        Make sure to switch aware of nearby balls to False.
        """
        pass
    
    # TODO: Finish this function.
    def locate_opponent(self, opposing_team_player):
        """
        While holding a ball, the npc locates the nearest oppenent.
        """
        pass
    
    # TODO: Finish this function.
    def throw_ball_at_opponent(self):
        """
        When an opponent is located, the npc throws the dodgeball at the opponent.
        """
        pass

    def get_distance(self, object_in_question):
        """
        Returns the distance of an object, npc, or player from the npc.
        """
         # Stores the npc's position and object's position in variables to be used in the distance equation.
        x1 = self.center_x
        y1 = self.center_y
        x2 = object_in_question.center_x
        y2 = object_in_question.center_y

        # Finds the horizontal and vertical distance between the points.
        vertical_distance = y2 - y1
        horizontal_distance = x2 - x1

        # Squares both values.
        square_root_of_vertical_distance = vertical_distance ** 2
        square_root_of_horizontal_distance = horizontal_distance ** 2
        
        # Adds the sum and stores them in a variable.
        distance_from_object = square_root_of_vertical_distance + square_root_of_horizontal_distance

        return distance_from_object


        

        