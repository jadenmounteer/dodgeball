"""
This file contains the myGame class which is used to set up the game logic.
The Mygame class uses the other classes to set up the game.
"""
# --- Imports ---
import arcade
import background_classes
import main
import player
import ball
import npc
 
class MyGame(arcade.Window):
    """
    Main application class.

    NOTE: Go ahead and delete the methods you don't need.
    If you do need a method, delete the 'pass' and replace it
    with your own code. Don't leave 'pass' in this program.
    """

    def __init__(self, width, height, title):
        #Inherits the Arcade parent class
        super().__init__(width, height, title)

        #Sets the background color for the game.
        arcade.set_background_color(main.BACKGROUND_COLOR)

        # If you have sprite lists, you should create them here,
        # and set them to None

        # Creates a gym using the Gym class.
        self.gym = background_classes.Gym()
        # Creates a player from the Player class to represent the player.
        self.player_avatar = player.Player()

        # Creates instances of Npc to represent team 2's npc's.
        self.npc1 = npc.Npc(centerx=50, centery=main.SCREEN_HEIGHT / 2, color=arcade.color.RED, team=2)

        # Creates instances of the Ball class to represent the dodgeballs.
        self.dodgeball_1 = ball.Ball(main.SCREEN_WIDTH -100, main.SCREEN_HEIGHT / 2, arcade.color.RED, main.SCREEN_WIDTH -100, main.SCREEN_HEIGHT / 2)
        self.dodgeball_2 = ball.Ball(main.SCREEN_WIDTH / 2, main.SCREEN_HEIGHT / 3, arcade.color.YELLOW, main.SCREEN_WIDTH / 2, main.SCREEN_HEIGHT / 3)
        self.dodgeball_3 = ball.Ball(main.SCREEN_WIDTH / 2, main.SCREEN_HEIGHT / 4, arcade.color.GREEN, main.SCREEN_WIDTH / 2, main.SCREEN_HEIGHT / 4)


    def setup(self):
        """ Set up the game variables. Call to re-start the game. """
        # Create your sprites and sprite lists here


    def on_draw(self):
        """
        Render the screen.
        """

        # This command should happen before we start drawing. It will clear
        # the screen to the background color, and erase what we drew last frame.
        arcade.start_render()

        # Draws the gym to the screen.
        self.gym.draw_gym()

        # Draws a dodgeballs to the screen.
        self.dodgeball_1.draw_ball()
        self.dodgeball_2.draw_ball()
        self.dodgeball_3.draw_ball()

        # Draws the player to the screen.
        self.player_avatar.draw_player()

        # Draws team 2's npcs to the screen.
        self.npc1.draw_npc()

    def on_update(self, delta_time):
        """
        All the logic to move, and the game logic goes here.
        Normally, you'll call update() on the sprite lists that
        need it.
        """

        # Checks to see if keys are being held, and then takes appropriate action.
        self.check_keys()
        
        # Moves the team 2 npcs
        self.npc1.advance(self.player_avatar, self.dodgeball_1, self.dodgeball_2, self.dodgeball_3)


        # Moves the dodgeballs and resets them if they are out of bounds.
        self.dodgeball_1.ball_advance(self.player_avatar)
        self.dodgeball_2.ball_advance(self.player_avatar)
        self.dodgeball_3.ball_advance(self.player_avatar)

        

    def check_keys(self):
        """
        Checks to see if the user is holding down a key.
        If so, calls the appropriate method.
        """
        #          ---PLAYER Movement ---
        # If the player is holding the right arrow key.
        if self.player_avatar.holding_right:
            # Moves the player up court.
            self.player_avatar.move_up_court()
        # If the player is holding the left arrow key.
        if self.player_avatar.holding_left:
            # Moves the player down court.
            self.player_avatar.move_down_court()
        # If the player is holding the down arrow key.
        if self.player_avatar.holding_down:
            # Moves the player to the left of the court.
            self.player_avatar.move_left()
        # If the player is holding the up arrow key.
        if self.player_avatar.holding_up:
            # Moves the player to the right of the court.
            self.player_avatar.move_right()

        # --- Holding and throwing a ball ---
        # If the player presses P.
        if self.player_avatar.holding_p:
            # If the player isn't currently holding a ball.
            if self.player_avatar.holding_ball == False:
                # Makes the player to pick up a ball.
                self.player_avatar.pick_up_ball(self.dodgeball_1)
                self.player_avatar.pick_up_ball(self.dodgeball_2)
                self.player_avatar.pick_up_ball(self.dodgeball_3)
        
        # If the player presses space.
        if self.player_avatar.holding_space:
        # Calls the player's throw_ball() method, which throws any ball the player is holding.
            self.player_avatar.throw_ball(self.dodgeball_1)
            self.player_avatar.throw_ball(self.dodgeball_2)
            self.player_avatar.throw_ball(self.dodgeball_3)

            
            # As you add more balls, call the pick up ball function on all of them.


    def on_key_press(self, key, key_modifiers):
        """
        Called whenever a key on the keyboard is pressed.
        Checks which key is being pressed and then switches the boolean value to True.

        For a full list of keys, see:
        http://arcade.academy/arcade.key.html
        """
        if key == arcade.key.UP:
            self.player_avatar.holding_up = True
        if key == arcade.key.DOWN:
            self.player_avatar.holding_down = True
        if key == arcade.key.RIGHT:
            self.player_avatar.holding_right = True
        if key == arcade.key.LEFT:
            self.player_avatar.holding_left = True
        if key == arcade.key.SPACE:
            self.player_avatar.holding_space = True
        if key == arcade.key.P:
            self.player_avatar.holding_p = True

    def on_key_release(self, key, key_modifiers):
        """
        Called whenever the user lets off a previously pressed key.
        Checks which key is not being pressed and then switches the boolean value to False.
        """
        if key == arcade.key.UP:
            self.player_avatar.holding_up = False
        if key == arcade.key.DOWN:
            self.player_avatar.holding_down = False
        if key == arcade.key.RIGHT:
            self.player_avatar.holding_right = False
        if key == arcade.key.LEFT:
            self.player_avatar.holding_left = False
        if key == arcade.key.SPACE:
            self.player_avatar.holding_space = False
        if key == arcade.key.P:
            self.player_avatar.holding_p = False

    def on_mouse_motion(self, x, y, delta_x, delta_y):
        """
        Called whenever the mouse moves. 
        """
        pass

    def on_mouse_press(self, x, y, button, key_modifiers):
        """
        Called when the user presses a mouse button.
        """
        pass

    def on_mouse_release(self, x, y, button, key_modifiers):
        """
        Called when a user releases a mouse button.
        """
        pass