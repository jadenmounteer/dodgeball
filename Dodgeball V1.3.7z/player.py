"""
File: Player.py
Author: Jaden Mounteer

This file creates a class for the player in the dodgeball game.
The player will be a circle on one side of the screen. He will be able to move around in all directions, but not be able to cross the center line.
He will be able to pick up balls and throw them at the other player.
"""
import arcade
import main

class Player():
    """
    This class represents the player in the game, which will be a circle for now.
    """
    def __init__(self):
        """
        Initiates the player's member variables.
        """
        self.center_x = main.SCREEN_WIDTH - 50 # Starts the player on the back wall, depending on the size of the screen.
        self.center_y = main.SCREEN_HEIGHT / 2 # Starts the player on the middle of the wall, depending on the size of the screen.
        self.radius = (main.SCREEN_HEIGHT * main.SCREEN_WIDTH) / 16000 # Determines the player's size by the area of the screen.
        self.color = arcade.color.BLUE
        self.speed = 5
        self.holding_ball = False
        
        # These are used if the player is holding down an arrow key.
        self.holding_right = False
        self.holding_left = False
        self.holding_up = False
        self.holding_down = False
        self.holding_space = False
        self.holding_p = False
    
    def draw_player(self):
        """
        Draws the player to the screen.
        """
        # Draws a circle to the screen to represent the player, for now.
        arcade.draw_circle_filled(center_x=self.center_x, center_y=self.center_y, radius=self.radius, color=self.color)
    
    def move_down_court(self):
        """
        Allows the player to move down the x axis.
        If the player attempts to cross the middle line, he is stopped.
        """
        # If the player reaches the middle line
        if self.center_x == main.SCREEN_WIDTH /2:
            # Stop him from going down the x axis.
            self.center_x = self.center_x
        else:
            # Move down the x axis.
            self.center_x -= self.speed
    
    def move_up_court(self):
        """
        Allows the player to move up the x axis.
        Stops him from going out of pounds on the right side of the court.
        """
        # If the player reaches the out of bounds line
        if self.center_x == main.SCREEN_WIDTH - 50:
            # Stops him from going further.
            self.center_x = self.center_x
        else:
            # Moves the player up the x axis.
            self.center_x += self.speed
    
    def move_right(self):
        """
        Allows the player to move up the y axis.
        Stops the player from going out of bounds.
        """
        # If the player reaches out of bounds.
        if self.center_y == main.SCREEN_HEIGHT - 50:
            # Stops the player from moving.
            self.center_y = self.center_y
        else:
            # Moves the player up the y axis.
            self.center_y += self.speed
    
    def move_left(self):
        """
        Allows the player to move down the y axis.
        Stops the player from going out of bounds.
        """
        # If the player reaches out of bounds.
        if self.center_y == 50:
            # Stops the player from moving.
            self.center_y = self.center_y
        else:
            # Moves the player down the y axis.
            self.center_y -= self.speed

    def pick_up_ball(self, ball):
        """
        Takes a ball as a parameter.
        Calculates the distance between the player and the ball and 
        causes the player to pick up a ball if he is close enough.
        If he picks up the ball, returns True.
        If not, returns False.
        """
        # Stores the players position and balls position in variables to be used in the distance equation.
        x1 = self.center_x
        y1 = self.center_y
        x2 = ball.center_x
        y2 = ball.center_y

        # Finds the horizontal and vertical distance between the points.
        vertical_distance = y2 - y1
        horizontal_distance = x2 - x1

        # Squares both values.
        square_root_of_vertical_distance = vertical_distance ** 2
        square_root_of_horizontal_distance = horizontal_distance ** 2
        
        # Adds the sum and stores them in a variable.
        distance_from_ball = square_root_of_vertical_distance + square_root_of_horizontal_distance

        # If the distance from the ball is less than or equal to 1225
        if distance_from_ball <= 1225:
            # The player grabs the ball. Sets returns True.
            print("The player grabbed the ball.")
            ball.being_held_by_player = True

    def throw_ball(self, ball):
        """
        Causes the player to throw the ball he has in his hands.
        Takes a ball as a parameter.
        If the ball is being held by the player, 
        changes the ball's being_thrown_by_player member variable to True.
        """
        if ball.being_held_by_player == True:
            ball.being_thrown_by_player = True


