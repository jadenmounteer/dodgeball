Welcome to Dodgeball.

---Installation---
Make sure Python3 is installed.
Download code from GitHub.
Unzip the file and click on the main.py file to run the game.

For MAC users:
Follow the steps above. However, you will need a virtual environment to run the game.
Open the game in Pycharm using a virtual environment. Save it, and you will be able to run the game.