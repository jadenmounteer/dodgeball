"""
File: ball.py
Author: Jaden Mounteer

This file represents the balls in the game.
They will spawn on the middle line. The player and enemies can pick them up and throw them.
"""
import arcade
import main

class Ball():
    """
    This class represents a ball. 
    It can be picked up and thrown.
    """
    def __init__(self, center_x, center_y, color, starting_x_position, starting_y_position):
        """
        Initiates the ball's member variables.
        """
        self.center_x = center_x
        self.center_y = center_y
        self.radius = 10
        self.color = color
        self.speed = 10
        self.being_held_by_player = False
        self.being_thrown_by_player = False
        self.starting_x_position = starting_x_position
        self.starting_y_position = starting_y_position
        self.is_bumped_by_player = False
    
    def draw_ball(self):
        """
        Draws a ball to the screen.
        """
        arcade.draw_circle_filled(center_x=self.center_x, center_y=self.center_y, radius=self.radius, color=self.color)
    
    def ball_advance(self, player):
        """
        Takes the player as a parameter.
        This method moves the ball if the ball is being held, bumped, or thrown.
        """
        # If the ball is being held by the player.
        if self.being_held_by_player == True:
            # Move the ball in accordance with the player's movements.
            self.center_x = player.center_x - player.radius
            self.center_y = player.center_y - player.radius
        
        # If the ball is thrown by the player.
        if self.being_thrown_by_player == True:
            # Changes the being_held_by_player member variable to False.
            self.being_held_by_player = False
            # Moves the ball away from the player.
            self.center_x -= 10
        
        # If the ball has fallen out of bounds.
        if self.center_x <= 0 or self.center_x >= main.SCREEN_WIDTH or self.center_y <= 0 or self.center_y >= main.SCREEN_HEIGHT:
            # Stops the ball from moving.
            self.being_thrown_by_player = False
            # Resets the ball to the starting positions.
            self.center_x = self.starting_x_position
            self.center_y = self.starting_y_position


        # Checks to see if the ball is bumped by the player.
        self.is_bumped_by_player = self.bumped_by_player(player)
        # If the ball is bumped by the player:
        if self.is_bumped_by_player == True:
            # Calls the roll away from player method.
            self.roll_away_from_player(player)

    def bumped_by_player(self, player):
        """
        Checks to see if the ball is bumped by the player.
        Calculates the distance.
        Judging by the distance, returns True or False.
        """
        # __Calculates the distance between the player and the ball.

        # Stores the players position and balls position in variables to be used in the distance equation.
        x1 = self.center_x
        y1 = self.center_y
        x2 = player.center_x
        y2 = player.center_y

        # Finds the horizontal and vertical distance between the points.
        vertical_distance = y2 - y1
        horizontal_distance = x2 - x1

        # Squares both values.
        square_root_of_vertical_distance = vertical_distance ** 2
        square_root_of_horizontal_distance = horizontal_distance ** 2

        # Adds the sum and stores them in a variable.
        distance_from_ball = square_root_of_vertical_distance + square_root_of_horizontal_distance

        # If the distance from the player is less than or equal to 900
        if distance_from_ball <= 900:
            # The ball is bumped by the player.
            return True
        else:
            return False

    def roll_away_from_player(self, player):
        """
        Causes the ball to roll away from the player.
        Judging by the player's location, the ball will roll in the
        opposite direction.
        :param player:
        :return: None
        """
        # If the player is up court from the ball
        if player.center_x > self.center_x:
            # Moves the ball away from the player down court.
            count = self.speed
            while count > 0:
                self.center_x -= 1
                count -= 1
        # If the player is down court from the ball
        elif player.center_x < self.center_x:
            # Moves the ball away from the player up court.
            count = self.speed
            while count > 0:
                self.center_x += 1
                count -= 1
        # If the player is above the ball
        elif player.center_y > self.center_y:
            # Moves the ball downward from the player.
            count = self.speed
            while count > 0:
                self.center_y -= 1
                count -= 1
        # If the player is below the ball
        elif player.center_y < self.center_y:
        # Moves the ball upward from the player.
            count = self.speed
            while count > 0:
                self.center_y += 1
                count -= 1
